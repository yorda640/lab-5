package prog1;

public class CannotFly implements FlyBehavior {
	public void fly() {
		System.out.println(" cannot fly ");
		
	}
}
