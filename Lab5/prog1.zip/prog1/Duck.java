package prog1;

public abstract class Duck {
	private FlyBehavior flyBehavior;
	private QuackBehavior quackBehavior;
	
	abstract void display();
	
	public void quack() {
		quackBehavior.quack();
	}
	
	public void swim() {
		System.out.println(" swimming ");
	}
	
	public void fly() {
		flyBehavior.fly();
	}
	
	protected void setFlyBehavior(FlyBehavior fly) {
		flyBehavior = fly;
	}
	protected void setQuackBehavior(QuackBehavior quack) {
		quackBehavior = quack;
	}
	
}
