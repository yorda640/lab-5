package prog1;

public interface QuackBehavior {
	abstract void quack();
}
