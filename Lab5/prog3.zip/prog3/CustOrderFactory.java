package prog3;

import java.time.LocalDate;

public class CustOrderFactory {
	private CustOrderFactory() {}
	public static Customer getCustomer(String name) {
		return new Customer(name);
	}
	
	public static Order newOrder(Customer cust, LocalDate date) {
		if(cust == null) throw new NullPointerException("Null customer");
		Order ord = new Order(date);
		cust.addOrder(ord);
		return ord;
	}
	
	public static void addOrder(Customer cust, Order order) {
		if(cust == null) throw new NullPointerException("Null customer");
		cust.addOrder(order);
	}
	
	public static Item newItem(String name) {
		return new Item(name);
	}
	public static void addItem(Order order, String name) {
		if(order == null) throw new NullPointerException("Null customer");
		order.addItem(name);
	}
}
