package prog2;

import java.util.ArrayList;


public class MainProgram {
	static private ArrayList<ClosedCurve> list;
	
	public static void main(String[] args) {
		list = new ArrayList<ClosedCurve>();
		list.add(new Rectangle(4,6));
		list.add(new Circle(2));
		list.add(new Triangle(4, 5));
		double sum = 0.0;
		for(ClosedCurve cc: list) {
			sum += cc.computeArea();
		}
		System.out.printf("Sum of Areas = %.2f ", sum);
	}

}
