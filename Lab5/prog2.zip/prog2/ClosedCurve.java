package prog2;

public interface ClosedCurve {
	
	public double computeArea();

}
